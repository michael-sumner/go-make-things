<?php

	if ( !defined( 'WPINC' ) ) {
		exit( 'Do NOT access this file directly: '.basename(__FILE__) );
	}


	/*
	 * Dynamically generate a new version salt based on the cookie
	 */
	function critical_css_salt_shaker( $version_salt ) {

		// Check for fullCSS cookie
		if ( isset($_COOKIE['fullCSS']) && $_COOKIE['fullCSS'] === 'true' ) {
			$version_salt .= 'fullcss'; // Give users with cached CSS files their own variation of the cache.
		} else {
			$version_salt .= 'inlinecss'; // A default group for all others.
		}

		// Check for fontsLoaded cookie
		if ( isset($_COOKIE['fontsLoaded']) && $_COOKIE['fontsLoaded'] === 'true' ) {
			$version_salt .= 'fontsloaded'; // Give users with cached CSS files their own variation of the cache.
		} else {
			$version_salt .= 'fontsnotloaded'; // A default group for all others.
		}

		return $version_salt;

	}


	/**
	 * Add a new version salt
	 */
	function critical_css_salt_plugin() {
		$ac = $GLOBALS['comet_cache_advanced_cache'];
		$ac->addFilter('comet_cache_version_salt', 'critical_css_salt_shaker');
	}
	critical_css_salt_plugin();