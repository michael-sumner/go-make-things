<?php

/**
 * functions-boilerplate.php
 * A boilerplate for WordPress performance modifications and enhancements.
 *
 * TO USE:
 * 1. Make a copy of this file.
 * 2. Rename it functions.php.
 * 3. Delete all of the stuff you don't need.
 * 4. Replace `/path/to/your/` with the path to your actual files in your theme directory, treating your theme file as the root directory. For example, `/dist/js/main.js`.
 *
 * DO NOT copy this file verbatim into your theme. It will break all the things!
 */


	//
	// ---------------------------
	// CHAPTER
	// Loading CSS Better
	// ---------------------------
	//

	/**
	 * Load theme styles the traditional way if cached
	 */
	function load_theme_styles() {
		if ( isset($_COOKIE['fullCSS']) && $_COOKIE['fullCSS'] === 'true' ) {
			wp_enqueue_style( 'theme-styles', get_template_directory_uri() . '/path/to/your/main.css', null, null, 'all' );
		}
	}
	add_action('wp_enqueue_scripts', 'load_theme_styles');


	/**
	 * Load theme styles the traditional way if cached, with cache-busting for minified files
	 */
	function load_theme_styles_cache_busting() {
		if ( isset($_COOKIE['fullCSS']) && $_COOKIE['fullCSS'] === 'true' ) {
			$theme = wp_get_theme(); // Get theme info
			wp_enqueue_style( 'theme-styles', get_template_directory_uri() . '/path/to/your/main.min.' . $theme->get( 'Version' ) . '.css', null, null, 'all' );
		}
	}
	add_action('wp_enqueue_scripts', 'load_theme_styles_cache_busting');


	/**
	 * Load critical path CSS inline in the header and async the full stylesheet if not cached
	 */
	function load_critical_css_inline_header() {
		if ( !isset($_COOKIE['fullCSS']) || $_COOKIE['fullCSS'] !== 'true' ) :
		?>
			<style type="text/css">
				/**
				 * Your critical path CSS goes here...
				 */
			</style>
			<script>
				function loadCSS(e,t,n){"use strict";function r(){for(var t,i=0;i<d.length;i++)d[i].href&&d[i].href.indexOf(e)>-1&&(t=!0);t?o.media=n||"all":setTimeout(r)}var o=window.document.createElement("link"),i=t||window.document.getElementsByTagName("script")[0],d=window.document.styleSheets;return o.rel="stylesheet",o.href=e,o.media="only x",i.parentNode.insertBefore(o,i),r(),o}
				function onloadCSS(n,o){n.onload=function(){n.onload=null,o&&o.call(n)},"isApplicationInstalled"in navigator&&"onloadcssdefined"in n&&n.onloadcssdefined(o)}
				var stylesheet = loadCSS( "<?php echo get_template_directory_uri() . '/path/to/your/main.css'; ?>" );
				onloadCSS( stylesheet, function() {
					var expires = new Date(+new Date + (7 * 24 * 60 * 60 * 1000)).toUTCString();
					document.cookie = 'fullCSS=true; expires=' + expires;
				});
			</script>
		<?php
		endif;
	}
	add_action('wp_head', 'load_critical_css_inline_header', 30);


	/**
	 * Load critical path CSS inline in the header and async the full stylesheet if not cached
	 * This version uses file_get_contents() so you don't have to copy/paste your inline code
	 */
	function load_critical_css_auto_inline_header() {
		if ( !isset($_COOKIE['fullCSS']) || $_COOKIE['fullCSS'] !== 'true' ) :
		?>
			<style type="text/css">
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/your/critical.css' ); ?>
			</style>
			<script>
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/loadCSS.js' ); ?>
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/onloadCSS.js' ); ?>
				var stylesheet = loadCSS( "<?php echo get_template_directory_uri() . '/path/to/your/main.css'; ?>" );
				onloadCSS( stylesheet, function() {
					var expires = new Date(+new Date + (7 * 24 * 60 * 60 * 1000)).toUTCString();
					document.cookie = 'fullCSS=true; expires=' + expires;
				});
			</script>
		<?php
		endif;
	}
	add_action('wp_head', 'load_critical_css_auto_inline_header', 30);


	/**
	 * Load critical path CSS inline in the header and async the full stylesheet if not cached
	 * This version uses file_get_contents() so you don't have to copy/paste your inline code, and includes cache-busting for minified files
	 */
	function load_critical_css_auto_inline_header_cache_busting() {

		// Get theme info
		$theme = wp_get_theme();

		if ( !isset($_COOKIE['fullCSS']) || $_COOKIE['fullCSS'] !== 'true' ) :
		?>
			<style type="text/css">
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/your/critical.min.' . $theme->get( 'Version' ) . '.css' ); ?>
			</style>
			<script>
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/loadCSS.min.' . $theme->get( 'Version' ) . '.js' ); ?>
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/onloadCSS.min.' . $theme->get( 'Version' ) . '.js' ); ?>
				var stylesheet = loadCSS( "<?php echo get_template_directory_uri() . '/path/to/your/main.min.' . $theme->get( 'Version' ) . '.css'; ?>" );
				onloadCSS( stylesheet, function() {
					var expires = new Date(+new Date + (7 * 24 * 60 * 60 * 1000)).toUTCString();
					document.cookie = 'fullCSS=true; expires=' + expires;
				});
			</script>
		<?php
		endif;
	}
	add_action('wp_head', 'load_critical_css_auto_inline_header_cache_busting', 30);


	/**
	 * Load fallback CSS in the footer if not cached
	 */
	function load_fallback_css_footer() {
		if ( !isset($_COOKIE['fullCSS']) || $_COOKIE['fullCSS'] !== 'true' ) :
		?>
			<noscript>
				<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() . '/path/to/your/main.css'; ?>">
			</noscript>
		<?php
		endif;
	}
	add_action('wp_footer', 'load_fallback_css_footer', 30);


	/**
	 * Load fallback CSS in the footer if not cached, with cache-busting for minified files
	 */
	function load_fallback_css_footer_cache_busting() {

		// Get theme info
		$theme = wp_get_theme();

		if ( !isset($_COOKIE['fullCSS']) || $_COOKIE['fullCSS'] !== 'true' ) :
		?>
			<noscript>
				<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() . '/path/to/your/main.min.' . $theme->get( 'Version' ) . '.css'; ?>">
			</noscript>
		<?php
		endif;
	}
	add_action('wp_footer', 'load_fallback_css_footer_cache_busting', 30);





	//
	// ---------------------------
	// CHAPTER
	// Loading JavaScript Better
	// ---------------------------
	//

	/**
	 * Load feature detection in the header and main JS files in the footer
	 */
	function load_theme_scripts() {

		// Feature detects: loads in header
		wp_enqueue_script( 'theme-detects', get_template_directory_uri() . '/path/to/your/detects.js', null, null, false );

		// Main scripts: loads in footer
		wp_enqueue_script( 'theme-scripts', get_template_directory_uri() . '/path/to/your/main.js', null, null, true );

	}
	add_action('wp_enqueue_scripts', 'load_theme_scripts');


	/**
	 * Load feature detection in the header and main JS files in the footer, with cache-busting for minified files
	 */
	function load_theme_scripts_cache_busting() {

		// Get theme info
		$theme = wp_get_theme();

		// Feature detects: loads in header
		wp_enqueue_script( 'theme-detects', get_template_directory_uri() . '/path/to/your/detects.min.' . $theme->get( 'Version' ) . '.js', null, null, false );

		// Main scripts: loads in footer
		wp_enqueue_script( 'theme-scripts', get_template_directory_uri() . '/path/to/your/main.min.' . $theme->get( 'Version' ) . '.js', null, null, true );

	}
	add_action('wp_enqueue_scripts', 'load_theme_scripts_cache_busting');


	/**
	 * Load feature detection scripts inline in the header
	 */
	function load_scripts_inline_header() {
		?>
			<script>
				// Your feature detection scripts get inlined here...
			</script>
		<?php
	}
	add_action('wp_head', 'load_scripts_inline_header', 30);


	/**
	 * Load feature detection scripts inline in the header
	 * This version uses file_get_contents() so you don't have to copy/paste your inline code
	 */
	function load_scripts_auto_inline_header() {
		?>
			<script>
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/your/detects.js' ); ?>
			</script>
		<?php
	}
	add_action('wp_head', 'load_scripts_auto_inline_header', 30);


	/**
	 * Load feature detection scripts inline in the header
	 * This version uses file_get_contents() so you don't have to copy/paste your inline code, and cache-busting for minified files
	 */
	function load_scripts_auto_inline_header() {
		$theme = wp_get_theme(); // Get theme info
		?>
			<script>
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/your/detects.min.' . $theme->get( 'Version' ) . '.js' ); ?>
			</script>
		<?php
	}
	add_action('wp_head', 'load_scripts_auto_inline_header', 30);




	//
	// ---------------------------
	// CHAPTER
	// Fixing Fonts
	// ---------------------------
	//

	/**
	 * Load fonts the traditional way if cached
	 */
	function load_fonts() {
		if ( isset($_COOKIE['fontsLoaded']) && $_COOKIE['fontsLoaded'] === 'true' ) {
			wp_enqueue_style( 'theme-fonts', '//fonts.googleapis.com/css?family=PT+Serif:400,400italic,700,700italic', null, null, 'all' );
		}
	}
	add_action('wp_enqueue_scripts', 'load_fonts');


	/**
	 * Load fonts async if not cached
	 */
	function load_fonts_async() {
		if ( !isset($_COOKIE['fontsLoaded']) || $_COOKIE['fontsLoaded'] !== 'true' ) :
		?>
			<script>
				// Inline loadCSS if you haven't done so elsewhere
				function loadCSS(e,t,n){"use strict";function r(){for(var t,i=0;i<d.length;i++)d[i].href&&d[i].href.indexOf(e)>-1&&(t=!0);t?o.media=n||"all":setTimeout(r)}var o=window.document.createElement("link"),i=t||window.document.getElementsByTagName("script")[0],d=window.document.styleSheets;return o.rel="stylesheet",o.href=e,o.media="only x",i.parentNode.insertBefore(o,i),r(),o}

				// Inline Font Face Observer
				!function(){"use strict";function t(t){l.push(t),1==l.length&&f()}function e(){for(;l.length;)l[0](),l.shift()}function n(t){this.a=u,this.b=void 0,this.f=[];var e=this;try{t(function(t){r(e,t)},function(t){a(e,t)})}catch(n){a(e,n)}}function i(t){return new n(function(e,n){n(t)})}function o(t){return new n(function(e){e(t)})}function r(t,e){if(t.a==u){if(e==t)throw new TypeError;var n=!1;try{var i=e&&e.then;if(null!=e&&"object"==typeof e&&"function"==typeof i)return void i.call(e,function(e){n||r(t,e),n=!0},function(e){n||a(t,e),n=!0})}catch(o){return void(n||a(t,o))}t.a=0,t.b=e,c(t)}}function a(t,e){if(t.a==u){if(e==t)throw new TypeError;t.a=1,t.b=e,c(t)}}function c(e){t(function(){if(e.a!=u)for(;e.f.length;){var t=e.f.shift(),n=t[0],i=t[1],o=t[2],t=t[3];try{0==e.a?o("function"==typeof n?n.call(void 0,e.b):e.b):1==e.a&&("function"==typeof i?o(i.call(void 0,e.b)):t(e.b))}catch(r){t(r)}}})}function s(t){return new n(function(e,n){function i(n){return function(i){a[n]=i,r+=1,r==t.length&&e(a)}}var r=0,a=[];0==t.length&&e(a);for(var c=0;c<t.length;c+=1)o(t[c]).c(i(c),n)})}function d(t){return new n(function(e,n){for(var i=0;i<t.length;i+=1)o(t[i]).c(e,n)})}var f,l=[];f=function(){setTimeout(e)};var u=2;n.prototype.g=function(t){return this.c(void 0,t)},n.prototype.c=function(t,e){var i=this;return new n(function(n,o){i.f.push([t,e,n,o]),c(i)})},window.Promise||(window.Promise=n,window.Promise.resolve=o,window.Promise.reject=i,window.Promise.race=d,window.Promise.all=s,window.Promise.prototype.then=n.prototype.c,window.Promise.prototype["catch"]=n.prototype.g)}(),function(){function t(t,e){d?t.addEventListener("scroll",e,!1):t.attachEvent("scroll",e)}function e(t){document.body?t():d?document.addEventListener("DOMContentLoaded",t):document.attachEvent("onreadystatechange",function(){"interactive"!=document.readyState&&"complete"!=document.readyState||t()})}function n(t){this.a=document.createElement("div"),this.a.setAttribute("aria-hidden","true"),this.a.appendChild(document.createTextNode(t)),this.b=document.createElement("span"),this.c=document.createElement("span"),this.h=document.createElement("span"),this.f=document.createElement("span"),this.g=-1,this.b.style.cssText="max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;",this.c.style.cssText="max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;",this.f.style.cssText="max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;",this.h.style.cssText="display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;",this.b.appendChild(this.h),this.c.appendChild(this.f),this.a.appendChild(this.b),this.a.appendChild(this.c)}function i(t,e){t.a.style.cssText="max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;left:-999px;white-space:nowrap;font:"+e+";"}function o(t){var e=t.a.offsetWidth,n=e+100;return t.f.style.width=n+"px",t.c.scrollLeft=n,t.b.scrollLeft=t.b.scrollWidth+100,t.g!==e?(t.g=e,!0):!1}function r(e,n){function i(){var t=r;o(t)&&null!==t.a.parentNode&&n(t.g)}var r=e;t(e.b,i),t(e.c,i),o(e)}function a(t,e){var n=e||{};this.family=t,this.style=n.style||"normal",this.weight=n.weight||"normal",this.stretch=n.stretch||"normal"}function c(){if(null===l){var t=document.createElement("div");try{t.style.font="condensed 100px sans-serif"}catch(e){}l=""!==t.style.font}return l}function s(t,e){return[t.style,t.weight,c()?t.stretch:"","100px",e].join(" ")}var d=!!document.addEventListener,f=null,l=null,u=!!window.FontFace;a.prototype.load=function(t,o){var a=this,c=t||"BESbswy",d=o||3e3,l=(new Date).getTime();return new Promise(function(t,o){if(u){var h=new Promise(function(t,e){function n(){(new Date).getTime()-l>=d?e():document.fonts.load(s(a,a.family),c).then(function(e){1<=e.length?t():setTimeout(n,25)},function(){e()})}n()}),p=new Promise(function(t,e){setTimeout(e,d)});Promise.race([p,h]).then(function(){t(a)},function(){o(a)})}else e(function(){function e(){var e;(e=-1!=m&&-1!=v||-1!=m&&-1!=y||-1!=v&&-1!=y)&&((e=m!=v&&m!=y&&v!=y)||(null===f&&(e=/AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent),f=!!e&&(536>parseInt(e[1],10)||536===parseInt(e[1],10)&&11>=parseInt(e[2],10))),e=f&&(m==b&&v==b&&y==b||m==g&&v==g&&y==g||m==x&&v==x&&y==x)),e=!e),e&&(null!==T.parentNode&&T.parentNode.removeChild(T),clearTimeout(E),t(a))}function u(){if((new Date).getTime()-l>=d)null!==T.parentNode&&T.parentNode.removeChild(T),o(a);else{var t=document.hidden;!0!==t&&void 0!==t||(m=h.a.offsetWidth,v=p.a.offsetWidth,y=w.a.offsetWidth,e()),E=setTimeout(u,50)}}var h=new n(c),p=new n(c),w=new n(c),m=-1,v=-1,y=-1,b=-1,g=-1,x=-1,T=document.createElement("div"),E=0;T.dir="ltr",i(h,s(a,"sans-serif")),i(p,s(a,"serif")),i(w,s(a,"monospace")),T.appendChild(h.a),T.appendChild(p.a),T.appendChild(w.a),document.body.appendChild(T),b=h.a.offsetWidth,g=p.a.offsetWidth,x=w.a.offsetWidth,u(),r(h,function(t){m=t,e()}),i(h,s(a,'"'+a.family+'",sans-serif')),r(p,function(t){v=t,e()}),i(p,s(a,'"'+a.family+'",serif')),r(w,function(t){y=t,e()}),i(w,s(a,'"'+a.family+'",monospace'))})})},window.FontFaceObserver=a,window.FontFaceObserver.prototype.check=window.FontFaceObserver.prototype.load=a.prototype.load,"undefined"!=typeof module&&(module.exports=window.FontFaceObserver)}();

				// Load the font async
				loadCSS('//fonts.googleapis.com/css?family=PT+Serif:400,400italic,700,700italic');

				// When font loads, add .fonts-loaded class to <html> element
				var font = new FontFaceObserver('PT Serif');
				font.load().then(function () {
					var expires = new Date(+new Date() + (7 * 24 * 60 * 60 * 1000)).toUTCString();
					document.cookie = 'fontsLoaded=true; expires=' + expires;
					document.documentElement.className += ' fonts-loaded';
				});
			</script>
		<?php
		endif;
	}
	add_action('wp_head', 'load_fonts_async', 30);


	/**
	 * Load fonts async if not cached
	 * This version uses file_get_contents() so you don't have to copy/paste your inline code
	 */
	function load_fonts_auto_async() {
		if ( !isset($_COOKIE['fontsLoaded']) || $_COOKIE['fontsLoaded'] !== 'true' ) :
		?>
			<script>
				// Inline loadCSS if you haven't done so elsewhere
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/loadCSS.js' ); ?>

				// Inline Font Face Observer
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/fontfaceobserver.js' ); ?>

				// Load the font async
				loadCSS('//fonts.googleapis.com/css?family=PT+Serif:400,400italic,700,700italic');

				// When font loads, add .fonts-loaded class to <html> element
				var font = new FontFaceObserver('PT Serif');
				font.load().then(function () {
					var expires = new Date(+new Date() + (7 * 24 * 60 * 60 * 1000)).toUTCString();
					document.cookie = 'fontsLoaded=true; expires=' + expires;
					document.documentElement.className += ' fonts-loaded';
				});
			</script>
		<?php
		endif;
	}
	add_action('wp_head', 'load_fonts_auto_async', 30);


	/**
	 * Load fonts async if not cached
	 * This version uses file_get_contents() so you don't have to copy/paste your inline code, and includes cache-busting for minified files
	 */
	function load_fonts_auto_async() {

		// Get theme info
		$theme = wp_get_theme();

		if ( !isset($_COOKIE['fontsLoaded']) || $_COOKIE['fontsLoaded'] !== 'true' ) :
		?>
			<script>
				// Inline loadCSS if you haven't done so elsewhere
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/loadCSS.min.' . $theme->get( 'Version' ) . '.js' ); ?>

				// Inline Font Face Observer
				<?php echo file_get_contents( get_template_directory_uri() . '/path/to/fontfaceobserver.min.' . $theme->get( 'Version' ) . '.js' ); ?>

				// Load the font async
				loadCSS('//fonts.googleapis.com/css?family=PT+Serif:400,400italic,700,700italic');

				// When font loads, add .fonts-loaded class to <html> element
				var font = new FontFaceObserver('PT Serif');
				font.load().then(function () {
					var expires = new Date(+new Date() + (7 * 24 * 60 * 60 * 1000)).toUTCString();
					document.cookie = 'fontsLoaded=true; expires=' + expires;
					document.documentElement.className += ' fonts-loaded';
				});
			</script>
		<?php
		endif;
	}
	add_action('wp_head', 'load_fonts_auto_async', 30);