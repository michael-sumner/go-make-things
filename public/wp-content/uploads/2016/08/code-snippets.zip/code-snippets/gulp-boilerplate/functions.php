<?php

/**
 * functions.php
 * For modifying and expanding core WordPress functionality.
 */


	/**
	 * Load theme files
	 */
	function load_theme_files() {

		// Get theme info
		$theme = wp_get_theme();

		// Theme styles
		wp_enqueue_style( 'theme-styles', get_template_directory_uri() . '/dist/css/main.min.' . $theme->get( 'Version' ) . '.css', null, null, 'all' );

		// Theme scripts (loaded in the footer)
		wp_enqueue_script( 'theme-scripts', get_template_directory_uri() . '/dist/js/main.min.' . $theme->get( 'Version' ) . '.js', null, false, true );

	}
	add_action( 'wp_enqueue_scripts', 'load_theme_files' );



	/**
	 * Load inline header content
	 */
	function load_inline_header() {

		// Get theme info
		$theme = wp_get_theme();

		?>
			<script>
				// Feature detection scripts
				<?php
					echo file_get_contents(
						get_template_directory_uri() . '/dist/js/detects.min.' . $theme->get( 'Version' ) . '.js'
					);
				?>
			</script>
		<?php

	}
	add_action( 'wp_head', 'load_inline_header', 30 );