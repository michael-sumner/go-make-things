;(function (window, document, undefined) {

	'use strict';

	// Canvas feature detection
	var elem = document.createElement( 'canvas' );
	var supports = !!( elem.getContext && elem.getContext( '2d' ) );
	if ( !supports ) return;

	// Add `.canvas` class to <html> element
	document.documentElement.className += (document.documentElement.className ? ' ' : '') + 'canvas';

})(window, document);