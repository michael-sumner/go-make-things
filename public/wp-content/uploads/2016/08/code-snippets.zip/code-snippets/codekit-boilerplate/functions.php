<?php

/**
 * functions.php
 * For modifying and expanding core WordPress functionality.
 */


	/**
	 * Load theme files
	 */
	function load_theme_files() {

		// Styles
		wp_enqueue_style( 'theme-styles', get_template_directory_uri() . '/css/main.css', null, null, 'all' );

		// Feature detects - load in header
		wp_enqueue_script( 'theme-detects', get_template_directory_uri() . '/js/min/detects.js', null, null, false );

		// Main scripts - load in footer
		wp_enqueue_script( 'theme-scripts', get_template_directory_uri() . '/js/min/main.js', null, null, true );

	}
	add_action( 'wp_enqueue_styles', 'load_theme_files' );