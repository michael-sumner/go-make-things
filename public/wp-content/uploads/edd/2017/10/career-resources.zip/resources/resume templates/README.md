# Resume Templates

The Ultimate Resume Template comes in two variants:

1. Traditional, a reverse chronological list of work history.
2. Project Based, which puts a greater focus on project work.

If you've spent a lot of your career as a freelancer and are looking to move in-house, or if you're a recent graduation and most of your experience is project work, use the Project Based template. Otherwise, use the traditional template.

Examples of both are included.